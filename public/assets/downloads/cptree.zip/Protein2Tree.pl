#!/usr/bin/perl -w
use strict;
use LWP::Simple;
use Getopt::Long;

require "./cpData.pl";

# build DB: perl batchDownload.pl -i list.txt -o cpdb
# test 16s: perl Protein2Tree.pl -i list.txt -g gene.txt -c default_config.txt -o result_protein > result_protein/run.log

# orgnized the input
my $nc_number_list;
my $gene_name_list;
my $config_filename;
my $output;

GetOptions(
        "input|i=s" => \$nc_number_list,
        "gene|g=s" => \$gene_name_list,
        "config|c=s" => \$config_filename,
        "output|o=s" => \$output
        );

# read name list
my $input_name = file2str($nc_number_list);
print mylog("INFO", "Reading input name list.");
chomp $input_name;
print mylog("DEBUG", "Name List: $input_name");
my %h = readDBToHash($input_name);
print mylog("INFO", "Reading data file.");

# read gene list
my $input_gene = file2str($gene_name_list);
print mylog("INFO", "Reading input gene list.");
chomp $input_gene;
print mylog("DEBUG", "Gene List: $input_gene");

my @genes = split(/,/,$input_gene);

# prepare data for tree building 
my $totree = "";
foreach my $nc (keys %h) {
    # for each species
    print mylog("DEBUG", "$nc is adding to list.");
    # echo >+NC Number
    $totree .= ">$nc\n";
    foreach my $key (keys %{$h{$nc}}) {
    	if ( $key eq 'CDS_Protein.txt') {
    		my $protein = $h{$nc}->{$key};
            # cut the long name into short
            my $protein_totree =  shortenName($protein);

            # fill in the data
            for (my $var = 0; $var < $#genes; $var++) {
                my $add = findGene($genes[$var], $protein_totree);
                $totree .= $add;
            }
    	}
    }
    $totree .= "\n";
}

# save data to output folder
mkdir $output;
addToFile($totree, "$output/tree.fa");
print mylog("INFO", "Protein list is ready: $output/tree.fa");


# read config and run
my $config = file2str($config_filename);
# defalt config: "-ALIGN -TREE -OUTPUT=NEXUS"
print mylog("INFO", "Building tree with clustalw...");
clustalw("-INFILE=$output/tree.fa $config");
print mylog("INFO", "Done.");

# filter the name into short name
sub shortenName{
    #CDSProtein FileStr
    my $protein = $_[0];

    my $reStr = "";
    # print $protein;
    my @lines = split(/\n/, $protein);
    foreach my $line ( @lines ) {
       chomp $line; 
        if($line =~ /^>lcl.*gene=(.*)\]\s+\[protein=(.*)\]\s+\[protein_id=.*/){
            $reStr .= ">$1\n";
        } else {
            $reStr .=  "$line\n";
        }
    }
    return $reStr;
}

#find gene content from protein file
sub findGene {
    #gene name
    #protein file

    my $geneName = $_[0];
    my $protein = $_[1];

    my %hGenes = readFastaToHash($protein);

    # missing some gene
    if ( !defined($hGenes{$geneName}) ) { 
        print mylog("WARN", "Miss $geneName, please check.");
        return "";
    };
    return $hGenes{$geneName};
}