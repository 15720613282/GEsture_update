#!/usr/bin/perl -w
use strict;
use LWP::Simple;
use Getopt::Long;

# build DB: perl batchDownload.pl -i list.txt -o cpdb
# test 16s:  perl rRNA2tree.pl -i list.txt -g cp_16s -c default_config.txt -o result_16s> result_16s/run.log
# test 23s: perl rRNA2tree.pl -i list.txt -g cp_23s -c default_config.txt -o result_23s > result_23s/run.log

require "./cpData.pl";

my $nc_number_list;
my $rna_name;
my $config_filename;
my $output;

GetOptions(
        "input|i=s" => \$nc_number_list,
        "gene|g=s" => \$rna_name, # can only be cp_16s or cp_23s
        "config|c=s" => \$config_filename,
        "output|o=s" => \$output
        );
mkdir $output;

# read file list
my $input_content = file2str($nc_number_list);
print mylog("INFO", "Reading input list.");
chomp $input_content;
print mylog("DEBUG", "LIST: $input_content");
my %h = readDBToHash($input_content);
print mylog("INFO", "Reading data file.");

# prepare data
my $totree = "";
foreach my $nc (keys %h) {
    print mylog("DEBUG", "Adding $nc to tree.");
    foreach my $key (keys %{$h{$nc}}) {
    	my $v = $h{$nc}->{$key};
    	if ( $key eq "$rna_name.fa") {
    		$totree .= "$v";	
    	}
    }
}

# save data to output folder
addToFile($totree, "$output/tree.fa");
print mylog("INFO", "rRNA List is ready.");

# read config and run
my $config = file2str($config_filename);
# defalt config: "-ALIGN -TREE -OUTPUT=NEXUS"
print mylog("INFO", "Building tree with clustalw...");
clustalw("-INFILE=$output/tree.fa $config");
print mylog("INFO", "Done.");